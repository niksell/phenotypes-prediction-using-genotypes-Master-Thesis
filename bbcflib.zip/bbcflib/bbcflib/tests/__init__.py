"""
=========================
Subpackage: bbcflib.tests
=========================

Provides unittesting to the library.

To run all the unitests, in the distribution directory, type::

   $ nosetests

"""
