.. automodule:: bbcflib.email
   :members:
