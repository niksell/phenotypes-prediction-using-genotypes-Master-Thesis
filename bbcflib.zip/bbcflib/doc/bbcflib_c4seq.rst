.. automodule:: bbcflib.c4seq
   :members:
