.. automodule:: bbcflib.genrep
   :members:

.. autoclass:: GenRep
    :members:

.. autoclass:: Assembly
    :members:
