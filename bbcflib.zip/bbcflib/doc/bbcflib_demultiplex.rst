.. automodule:: bbcflib.demultiplex
   :members:
