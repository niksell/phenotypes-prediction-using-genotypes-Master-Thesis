.. automodule:: bbcflib.maplot
    :members:
    :member-order: bysource
    :show-inheritance:
