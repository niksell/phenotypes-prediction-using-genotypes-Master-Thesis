Demultiplexing
==============


