.. automodule:: bbcflib.mapseq
    :members:

    .. autofunction:: bowtie
    .. autofunction:: bowtie2
    .. autofunction:: bamstats
    .. autofunction:: plot_stats
    .. autofunction:: bam_to_density
