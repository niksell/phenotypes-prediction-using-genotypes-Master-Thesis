.. automodule:: bbcflib.chipseq
   :members:
   
   .. autofunction:: macs
   .. autofunction:: camelPeaks
