.. automodule:: bbcflib.rnaseq
    :members:
    :member-order: bysource
    :show-inheritance:

